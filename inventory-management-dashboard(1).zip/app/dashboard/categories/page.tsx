'use client'

import { useState } from 'react'
import { useAppSelector, useAppDispatch } from '@/lib/hooks'
import { addCategory, updateCategory, deleteCategory, toggleCategoryStatus } from '@/lib/slices/categoriesSlice'
import CategoriesGrid from '@/components/categories-grid'
import CategoryDialog from '@/components/category-dialog'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Plus, Book, ShoppingCart } from 'lucide-react'
import { Category } from '@/lib/slices/categoriesSlice'
import CategoryForm from '@/components/category-form' // Declare the CategoryForm variable

export default function CategoriesPage() {
  const categories = useAppSelector((state) => state.categories.items)
  const dispatch = useAppDispatch()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [showForm, setShowForm] = useState(false) // Declare the showForm variable

  const handleCloseForm = () => {
    setShowForm(false)
    setEditingCategory(null)
  }

  const handleAddCategory = (category: Omit<Category, 'id' | 'createdAt' | 'itemCount'>) => {
    const newCategory: Category = {
      ...category,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      itemCount: 0,
    }
    dispatch(addCategory(newCategory))
    setDialogOpen(false)
  }

  const handleUpdateCategory = (category: Omit<Category, 'createdAt'>) => {
    dispatch(
      updateCategory({
        ...category,
        createdAt: editingCategory?.createdAt || new Date().toISOString(),
      })
    )
    setEditingCategory(null)
    setDialogOpen(false)
  }

  const handleToggleStatus = (id: string) => {
    dispatch(toggleCategoryStatus(id))
  }

  const handleDeleteCategory = (id: string) => {
    if (confirm('Bu kategoriyi silmek istediğinize emin misiniz?')) {
      dispatch(deleteCategory(id))
    }
  }

  const handleEdit = (category: Category) => {
    setEditingCategory(category)
    setDialogOpen(true)
  }

  const handleDialogOpenChange = (open: boolean) => {
    setDialogOpen(open)
    if (!open) {
      setEditingCategory(null)
    }
  }

  const bookCategories = categories.filter((c) => c.type === 'book')
  const stationeryCategories = categories.filter((c) => c.type === 'stationery')

  const stats = {
    totalCategories: categories.length,
    activeCategories: categories.filter((c) => c.active).length,
    inactiveCategories: categories.filter((c) => !c.active).length,
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Kategoriler</h1>
          <p className="text-muted-foreground mt-2">Kitap ve kırtasiye kategorilerini yönetin</p>
        </div>
        <Button className="gap-2 w-full sm:w-auto" onClick={() => setDialogOpen(true)}>
          <Plus className="w-4 h-4" />
          Yeni Kategori Ekle
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-card border border-border rounded-lg">
          <p className="text-sm text-muted-foreground">Toplam Kategori</p>
          <p className="text-2xl font-bold text-foreground mt-2">{stats.totalCategories}</p>
        </div>
        <div className="p-4 bg-card border border-border rounded-lg">
          <p className="text-sm text-muted-foreground">Aktif Kategoriler</p>
          <p className="text-2xl font-bold text-green-600 mt-2">{stats.activeCategories}</p>
        </div>
        <div className="p-4 bg-card border border-border rounded-lg">
          <p className="text-sm text-muted-foreground">Pasif Kategoriler</p>
          <p className="text-2xl font-bold text-muted-foreground mt-2">{stats.inactiveCategories}</p>
        </div>
      </div>

      {/* Dialog */}
      <CategoryDialog
        open={dialogOpen}
        category={editingCategory || undefined}
        onOpenChange={handleDialogOpenChange}
        onSubmit={editingCategory ? handleUpdateCategory : handleAddCategory}
      />

      {/* Tabs for Book and Stationery Categories */}
      <Tabs defaultValue="books" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="books" className="gap-2">
            <Book className="w-4 h-4" />
            <span className="hidden sm:inline">Kitap Kategorileri</span>
            <span className="sm:hidden">Kitaplar</span>
            <span className="ml-1 text-xs bg-primary/20 px-2 py-0.5 rounded-full">{bookCategories.length}</span>
          </TabsTrigger>
          <TabsTrigger value="stationery" className="gap-2">
            <ShoppingCart className="w-4 h-4" />
            <span className="hidden sm:inline">Kırtasiye Kategorileri</span>
            <span className="sm:hidden">Kırtasiye</span>
            <span className="ml-1 text-xs bg-primary/20 px-2 py-0.5 rounded-full">{stationeryCategories.length}</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="books" className="space-y-4">
          {bookCategories.length === 0 ? (
            <div className="text-center py-12 bg-muted/50 rounded-lg border border-border">
              <Book className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Henüz kitap kategorisi eklenmemiş</p>
              <Button className="mt-4 gap-2" onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4" />
                İlk Kategoriyi Ekle
              </Button>
            </div>
          ) : (
            <CategoriesGrid
              categories={bookCategories}
              onEdit={handleEdit}
              onDelete={handleDeleteCategory}
              onToggleStatus={handleToggleStatus}
            />
          )}
        </TabsContent>

        <TabsContent value="stationery" className="space-y-4">
          {stationeryCategories.length === 0 ? (
            <div className="text-center py-12 bg-muted/50 rounded-lg border border-border">
              <ShoppingCart className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Henüz kırtasiye kategorisi eklenmemiş</p>
              <Button className="mt-4 gap-2" onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4" />
                İlk Kategoriyi Ekle
              </Button>
            </div>
          ) : (
            <CategoriesGrid
              categories={stationeryCategories}
              onEdit={handleEdit}
              onDelete={handleDeleteCategory}
              onToggleStatus={handleToggleStatus}
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
